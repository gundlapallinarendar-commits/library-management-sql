# Library Management System (SQL)

A small relational database project built with MySQL. It models a library where members borrow books written by authors, and includes sample data and useful analytical queries.

## Features
- Normalized schema with primary keys, foreign keys, `UNIQUE` and `CHECK` constraints
- A view (`current_loans`) for books currently checked out
- 8 example queries covering JOINs, GROUP BY, aggregates, LEFT JOIN, and date functions

## Tables
| Table | Description |
|-------|-------------|
| `authors` | Author details |
| `books` | Book catalog with copies available |
| `members` | Library members |
| `loans` | Borrow and return records |

## ER Diagram
```
authors (1) ---- (N) books (1) ---- (N) loans (N) ---- (1) members
```

## How to Run
```bash
mysql -u root -p < schema.sql
mysql -u root -p < sample_data.sql
mysql -u root -p < queries.sql
```
Or open the files in MySQL Workbench and run them in the same order.

## Project Structure
```
library-management-sql/
├── schema.sql        # Database and tables
├── sample_data.sql   # Sample records
├── queries.sql       # Example queries
└── README.md
```

## Concepts Covered
Joins, aggregation, views, constraints, subset filtering with `NULL`, date arithmetic.
